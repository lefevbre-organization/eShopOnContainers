# How I used machine learning to classify emails and turn them into insights.

This is the code used for investigating the Enron email dataset through machine learning.

***Switch tags to see the code used for a specific part.***

[Part 1 available on Medium](https://medium.com/@anthonydm/how-i-used-machine-learning-to-classify-emails-and-turn-them-into-insights-efed37c1e66) 

[Part 2 available on Medium](https://medium.com/@anthonydm/how-i-used-machine-learning-to-classify-emails-and-turn-them-into-insights-part-2-6a8f26477c86) 

[@anthdm](https://twitter.com/anthdm) on Twitter
