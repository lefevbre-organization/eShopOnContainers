import { render } from 'react-dom';
import './index.css';
import * as React from 'react';
import { ScheduleComponent, ViewsDirective, ViewDirective, Day, Week, WorkWeek, Month, Agenda, Inject, Resize, DragAndDrop } from '@syncfusion/ej2-react-schedule';

import { extend } from '@syncfusion/ej2-base';
import { DatePickerComponent } from '@syncfusion/ej2-react-calendars';
import { SampleBase } from './sample-base';
import { PropertyPane } from './property-pane';
import  dataSource from './datasource.json';
import Iframe from 'react-iframe'


export class Default  extends React.Component {
    constructor() {
        super(...arguments);
        this.data = extend([], dataSource.scheduleData, null, true);
    }
    change(args) {
        this.scheduleObj.selectedDate = args.value;
        this.scheduleObj.dataBind();
    }
    onDragStart(args) {
        args.navigation.enable = true;
    }
    render() {
        return (<div className='schedule-control-section'>
        <div className='col-lg-6 control-section'>
          <div className='control-wrapper'>
          <Iframe url="https://lexbox-test-webgoogle.lefebvre.es/calendar?layout=iframe"
            width="754px"
            height="425px"
            id="myId"
            frameBorder="0"
            className="frame"
            display="initial"
            position="relative"/>
          </div>
        </div>        
      </div>);
    }
}

render(<Default />, document.getElementById('root'));