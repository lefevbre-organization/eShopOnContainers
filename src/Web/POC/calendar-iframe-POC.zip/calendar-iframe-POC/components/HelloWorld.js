import React from 'react';
 
import Iframe from 'react-iframe'
import './App.css';
 
function activateEvent(){
 window.dispatchEvent(
 new CustomEvent('setValue', {
 detail: { 
 idCaseFile: 'value'
 
 }
 })
 );
}
 
class HelloWorld extends React.Component {
	
	 constructor(props) {
        super(props);
		  this.state = {
            value: "Here the selected date",
		
		}
		}
 
 async componentDidMount() {
 
 window.addEventListener("message", event => {
	  
	 var obj = event.data

     var valueJ = JSON.stringify(obj);
	 
      console.log('addEventListener', event); 
     this.setState({
              value: valueJ
        });
 })
 
 // window.addEventListener('hola', event => {
 // console.log(event);
 // alert();
 // // IMPORTANT: check the origin of the data! 
 // if (event.origin.startsWith('http://localhost:3000')) { 
 // // The data was sent from your site.
 // // Data sent with postMessage is stored in event.data:
 // console.log(event.data); 
 
 // } else {
 // // The data was NOT sent from your site! 
 // // Be careful! Do not use it. This else branch is
 // // here just for clarity, you usually shouldn't need it.
 // return; 
 // } 
 
 
 // }); 
 
 }
 
 handleRemoveCaseFile(){
 alert('bien');
 }
 
 
 
 render() {
 
 return (<div className='schedule-control-section'>

 
 <div className='message'> {this.state.value}</div> 
 <div className='col-lg-6 control-section'>
 <div className='control-wrapper'>
 <Iframe url="http://localhost:3002/calendar?layout=iframe"
 width="754px"
 height="425px"
 id="myId"
 frameBorder="0"
 className="frame"
 display="initial"
 position="relative"/>
 </div>
 </div> 
 </div>);
 
 return (
 
 
 
 
 <div>
 <h1>new event ddd</h1>
 
 </div>
 );
 }
}
export default HelloWorld;